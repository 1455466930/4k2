{
    "spider": "./spider.jar",
    "wallpaper": "http://bobohome.ignorelist.com:20247/bing",
    "logo": "http://127.0.0.1:9978/file/TVBox/logo.png",
    "sites": [
        {
            "key": "豆瓣",
            "name": "豆瓣｜首页",
            "type": 3,
            "api": "csp_Douban",
            "searchable": 0
        },
 
        {
            "key": "配置中心",
            "name": "配置｜中心",
            "type": 3,
            "api": "csp_Config",
            "searchable": 0,
            "changeable": 0,
            "indexs": 0,
            "style": {
                "type": "rect",
                "ratio": 1.597
            }
        },
        {
            "key": "热播影视",
            "name": "热播｜影视",
            "type": 3,
            "api": "csp_AppRJ",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 0
        },
        {
            "key": "天天影视",
            "name": "天天｜影视",
            "type": 3,
            "api": "csp_AppRJ",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 0,
            "ext": "http://tt.ysdqjs.cn"
        },
        {
            "key": "浪酷影视",
            "name": "浪酷｜影视",
            "type": 3,
            "api": "csp_AppRJ",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 0,
            "ext": "http://v.lkuys.cn"
        },
        {
            "key": "腾讯视频",
            "name": "腾讯｜视频",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/腾讯视频.js"
        },
 
        {
            "key": "阿里云盘",
            "name": "阿里｜云盘",
            "type": 3,
            "api": "csp_PanAli",
            "searchable": 0,
            "filterable": 0,
            "changeable": 0,
            "style": {
                "type": "list",
                "ratio": 1.433
            },
            "ext": "./json/aliShare.json"
        },
        {
            "key": "夸克云盘",
            "name": "夸克｜云盘",
            "type": 3,
            "api": "csp_PanQuark",
            "searchable": 0,
            "filterable": 0,
            "changeable": 0,
            "style": {
                "type": "list",
                "ratio": 1.433
            },
            "ext": "./json/quarkShare.json"
        },
        {
            "key": "UC",
            "name": "UC｜云盘",
            "type": 3,
            "api": "csp_PanUc",
            "searchable": 0,
            "filterable": 0,
            "changeable": 0,
            "style": {
                "type": "list",
                "ratio": 1.433
            },
            "ext": "./json/ucShare.json"
        },
        {
            "key": "百度云盘",
            "name": "百度｜云盘",
            "type": 3,
            "api": "csp_PanBaiDu",
            "searchable": 0,
            "filterable": 0,
            "changeable": 0,
            "style": {
                "type": "list",
                "ratio": 1.433
            }
        },
        {
            "key": "短剧合集",
            "name": "短剧｜合集",
            "type": 3,
            "api": "./js/quark.min.js",
            "ext": "./js/短剧合集.js",
            "style": {
                "type": "list"
            }
        },
        {
            "key": "玩偶哥哥",
            "name": "玩偶｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebShare",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "ext": "./json/wogg.json?"
        },
        {
            "key": "木偶",
            "name": "木偶｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebShare",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "ext": "./json/mogg.json?"
        },
        {
            "key": "蜡笔",
            "name": "蜡笔｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebShare",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "ext": "./json/lb.json?"
        },
        {
            "key": "小米",
            "name": "小米｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebShare",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "ext": "./json/xm.json?"
        },
        {
            "key": "至臻",
            "name": "至臻｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebShare",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "ext": "./json/zz.json?"
        },
        {
            "key": "多多",
            "name": "多多｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebShare",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "ext": "./json/yyds.json?"
        },
        {
            "key": "欧哥",
            "name": "欧哥｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebShare",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "ext": "./json/og.json?"
        },
        {
            "key": "二小",
            "name": "二小｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebShare",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "ext": "./json/ex.json?"
        },
        {
            "key": "百家",
            "name": "百家｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebShare",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "ext": "./json/bj.json?"
        },
        {
            "key": "大玩",
            "name": "大玩｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebShare",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "ext": "./json/dawo.json?"
        },
        {
            "key": "虎斑",
            "name": "虎斑｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebShare",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "ext": "./json/hb.json?"
        },
        {
            "key": "闪电",
            "name": "闪电｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebShare",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "ext": "./json/sd.json?"
        },
        {
            "key": "下饭",
            "name": "下饭｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebShare",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "ext": "./json/xf.json?"
        },
        {
            "key": "团长",
            "name": "团长｜4K弹幕",
            "type": 3,
            "api": "csp_PanWebTz",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1
        },
        {
            "key": "雷鲸",
            "name": "雷鲸｜4K",
            "type": 3,
            "api": "csp_PanWebShareCloudLJ",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "style": {
                "type": "rect",
                "ratio": 1.433
            },
            "ext": "./json/lj.json?"
        },
        {
            "key": "概念",
            "name": "海绵｜4K",
            "type": 3,
            "api": "csp_PanWebShareCloudHM",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "style": {
                "type": "rect",
                "ratio": 1.433
            },
            "ext": "./json/hm.json?"
        },
        {
            "key": "Pan1",
            "name": "Pan1｜4K",
            "type": 3,
            "api": "csp_PanWebShareCloudHM",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "style": {
                "type": "rect",
                "ratio": 1.433
            },
            "ext": "./json/pan1.json?"
        },
        {
            "key": "趣盘",
            "name": "趣盘｜4K",
            "type": 3,
            "api": "csp_PanWebQu",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "style": {
                "type": "list",
                "ratio": 1.433
            },
            "ext": "w7TCmsONw6LDrsKYwoXCosKcwqDCrcKawqDDosKnwqTCoMKjwrPCosKpw7DDscKqXsKhwqXDqcOUw6jDrMOiwphewpPCn8OmwprCpsKZwqHCp8KZwqBXwrPCk8Khw5Tlh7/phJvmj5XlkJNc5Yel5L6K5ZGxwrPlv6vop7notbTmu4DnrInDlsKawqbCmcKhwpfClcKTwqLDssOjw67DhMOfwqxXalDCoMOqw6/DssOjaWZmV8O2"
        },
        {
            "key": "聚搜",
            "name": "聚搜｜4K",
            "type": 3,
            "api": "csp_PanWebSearch",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "style": {
                "type": "list",
                "ratio": 1.433
            },
            "ext": "./json/aliyunpansearch.json"
        },
        {
            "key": "星芽短剧",
            "name": "星芽｜短剧",
            "type": 3,
            "api": "csp_AppXY",
            "searchable": 1,
            "quickSearch": 0,
            "filterable": 0
        },
        {
            "key": "河马短剧",
            "name": "河马｜短剧",
            "type": 3,
            "api": "csp_AppHMDJ",
            "searchable": 1,
            "quickSearch": 0,
            "filterable": 0,
            "ext": "w7TCmsONw6LDrsKYwoXCosKcwqDCrcKawqDDosKnwqTCoMKjwrPCosKpw53Dr8KUwp7CmsKlw63Dp8Kow63DsFpcUFfDrcOcw6rCoMK0U1fCi+WGtemFoeaQmOWRncKl5Yem5L2K5ZCnauW+oeiov+i2t+a8iuetksOXWlxQV8Odw5jDncOrw7PCo8Kke8KVw7LCmsK0wpnCocKqwqXCqcKZwq/CqcKwwqDDtw=="
        },
        {
            "key": "爱看短剧",
            "name": "爱看｜短剧",
            "type": 3,
            "api": "./py/爱看短剧.py",
            "searchable": 1,
            "changeable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "playerType": 2
        },
        {
            "key": "爱我短剧",
            "name": "爱我｜短剧",
            "type": 3,
            "api": "csp_XBPQ",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "ext": "./XBPQ/爱我短剧.json"
        },
        {
            "key": "短剧网",
            "name": "短剧网｜短剧",
            "type": 3,
            "api": "csp_XBPQ",
            "ext": "./XBPQ/短剧网.json"
        },
      
        {
            "key": "HG影视",
            "name": "HG影视｜APP",
            "type": 3,
            "api": "csp_AppYsV2",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "ext": "https://cs.hgyx.vip/api2/api.php/app/"
        },
        {
            "key": "猎手影视",
            "name": "猎手｜APP",
            "type": 3,
            "api": "./py/猎手影视.py",
            "searchable": 1,
            "changeable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "playerType": 2
        },
        {
            "key": "火车影视",
            "name": "火车｜APP",
            "type": 3,
            "api": "./py/火车影视.py",
            "searchable": 1,
            "changeable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "playerType": 2
        },
        {
            "key": "美帕影视",
            "name": "美帕｜APP",
            "type": 3,
            "api": "./py/美帕影视.py",
            "searchable": 1,
            "changeable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "playerType": 2
        },
        {
            "key": "嗨皮影视",
            "name": "嗨皮｜APP",
            "type": 3,
            "api": "./py/嗨皮影视.py",
            "searchable": 1,
            "changeable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "playerType": 2
        },
        {
            "key": "巧技",
            "name": "巧技｜APP",
            "type": 3,
            "api": "csp_qiao2",
            "playerType": 2,
            "ext": "https://fs-im-kefu.7moor-fs1.com/ly/4d2c3f00-7d4c-11e5-af15-41bf63ae4ea0/1740038979341/cksp.txt"
        },
        {
            "key": "木头",
            "name": "木头｜APP",
            "type": 3,
            "api": "csp_Shark",
            "playerType": 1,
            "ext": "saHR0cDovL21pdG8ubWlub3R2LmNuL3xhYXNzZGR3d3h4bGxzeDF4fGJic3NxZGJic3NsbDI1c3g="
        },
        {
            "key": "永夜",
            "name": "永夜｜APP",
            "type": 3,
            "api": "csp_Muou",
            "playerType": 2,
            "ext": "caHR0cHM6Ly9yeHlzeXlkcy5vc3MtY24tY2hlbmdkdS5hbGl5dW5jcy5jb20vZ2V0YXBwLnR4dHxlYmFkM2YxYTU4YjEzOTMzfGViYWQzZjFhNThiMTM5MzN8MTAw"
        },
        {
            "key": "星河",
            "name": "星河｜APP",
            "type": 3,
            "api": "csp_Muou",
            "playerType": 2,
            "ext": "caHR0cDovL3Rlbmd4dW55dW5hbGl5dW4ub3NzLWNuLXNoYW5naGFpLmFsaXl1bmNzLmNvbS90ZW5neHVueXVuLnR4dHxmNWUydHg1M3lrcDZzMmM5fGY1ZTJ0eDUzeWtwNnMyYzl8MzYx"
        },
        {
            "key": "油条",
            "name": "油条｜APP",
            "type": 3,
            "api": "csp_Muou",
            "playerType": 2,
            "ext": "caHR0cDovLzU5LjE1My4xNjcuMTM3Ojg4OTl8NGQ4M2I4N2M0YzVlYTExMXw0ZDgzYjg3YzRjNWVhMTExfDQ2Mg=="
        },
        {
            "key": "二三",
            "name": "二三｜App",
            "type": 3,
            "api": "csp_Muou",
            "playerType": 2,
            "ext": "caHR0cHM6Ly8xMjN5c3cuY29tfDIz5b2x6KeGfDQuMS44"
        },
        {
            "key": "主角",
            "name": "主角｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 2,
            "ext": "caHR0cHM6Ly9kdHltLnpqeXkuY2MvZ2ctZ2V0YXBwL2dldC1nZy50eHR8UE1LYVprQXY0UXA1M0VXbnxQTUthWmtBdjRRcDUzRVdufDQyNQ=="
        },
        {
            "key": "时常",
            "name": "时常｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cDovLzExMS4xODAuMTk4LjQwOjExMTB8YXNnY3hoamt0czEyNDU3M3xhc2djeGhqa3RzMTI0NTczfDEwMQ=="
        },
        {
            "key": "雨滴",
            "name": "雨滴｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cHM6Ly95ZHlzZHluYW1pY2RvbWFpbm5hbWUuNjguZ3k6MTA2NzgvYzltMmpzMjk4eDgyaDYvbDltOGJ4MjNqMm8ycDlxL2R5bmFtaWNkb21haW5uYW1lLnR4dHxrOW8zcDJjOGI3bTN6MG84fGs5bzNwMmM4YjdtM3owbzh8MTAw"
        },
        {
            "key": "现代",
            "name": "现代｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "caHR0cHM6Ly9jbXMud2xiYnEueHl6fHNkZXYxNXJ3c2E5NmZzZGV8c2RldjE1cndzYTk2ZnNkZXwzMDA="
        },
        {
            "key": "淘气",
            "name": "淘气｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cHM6Ly9za2FwLm9zcy1jbi1oYW5nemhvdS5hbGl5dW5jcy5jb20vZ2V0LnR4dHw0OTkwNDg4MjQ4OTA0ODg0fDQ5OTA0ODgyNDg5MDQ4ODR8MTA3"
        },
        {
            "key": "玉米",
            "name": "玉米｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cHM6Ly93d3cuempjLmFwcC98YWI0ZTlhNDIxNjc1ZjE0YnxhYjRlOWE0MjE2NzVmMTRifDQ0Mg=="
        },
        {
            "key": "优质",
            "name": "优质｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cHM6Ly9sYnlzYXBpZHR5bWd4LjY4Lmd5OjE2Nzg5L2xieXNhcGlkdHltL2FwcC50eHR8YXBpYXBwbGJ5c2tleTE2OHxhcGlhcHBsYnlza2V5MTY4fDEwNw=="
        },
        {
            "key": "木叶",
            "name": "木叶｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 2,
            "ext": "saHR0cDovLzExMy40NS4yNDMuMjMzL211eWUudHh0fFJ1TjlMUnZ3VFJncFFucEt8UnVOOUxSdndUUmdwUW5wS3w1NDc="
        },
        {
            "key": "龙虾",
            "name": "龙虾｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cDovL3BweC5iangzNjUudG9wfHBpcGl4aWEyMTc1MjIzMjR8cGlwaXhpYTIxNzUyMjMyNHw1MDY="
        },
        {
            "key": "起点",
            "name": "起点｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cDovL2NhaWppLm8wYS5jbnw3MGZkNjFkOTkxZjQzMjU3fDcwZmQ2MWQ5OTFmNDMyNTd8MTAw"
        },
        {
            "key": "米兔",
            "name": "米兔｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cHM6Ly93d3cuempjLmFwcHxhYjRlOWE0MjE2NzVmMTRifGFiNGU5YTQyMTY3NWYxNGJ8NDQy"
        },
        {
            "key": "光速",
            "name": "光速｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cDovLzU5LjE1My4xNjcuMTM3Ojg4OTl8NGQ4M2I4N2M0YzVlYTExMXw0ZDgzYjg3YzRjNWVhMTExfDQ2Mg=="
        },
        {
            "key": "优秀",
            "name": "优秀｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cDovL2FpLnhpYW95dW4uaW5rfEtMckZxU2ptYzRPSWo3NkJ8S0xyRnFTam1jNE9Jajc2QnwzMDA="
        },
        {
            "key": "莉莉",
            "name": "莉莉｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cDovLzU5LjE1My4xNjcuMTg2OjEwMDk5fFBNS2Faa0F2NFFwNTNFV258UE1LYVprQXY0UXA1M0VXbnw0MjU="
        },
        {
            "key": "电影",
            "name": "电影｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cHM6Ly9jOHcyb3Y3dTV3ZzJ6MW84cDIxYy5hbGl5dW5jcy5jbGljazoyNzg5OXxrOW8zcDJjOGI3bTN6MG84fGs5bzNwMmM4YjdtM3owbzh8MTAw"
        },
        {
            "key": "奇妙",
            "name": "奇妙｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cDovLzE1NC4xMi45MS4yMTE6NjY4fDEyMzQ1Njc4OUFCQ0RFRkd8MTIzNDU2Nzg5QUJDREVGR3wxMDY="
        },
        {
            "key": "格格",
            "name": "格格｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 2,
            "ext": "jaHR0cDovLzExMS4xODAuMTk4LjQwOjExMTAvYXBpLnBocHxhc2djeGhqa3RzMTI0NTczfGFzZ2N4aGprdHMxMjQ1NzN8MTE5"
        },
        {
            "key": "悠悠",
            "name": "悠悠｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 2,
            "ext": "jaHR0cDovLzE1Ni4yMjUuMzAuNjU6NTU2Ni9hcGkucGhwfER4d0lzdHJkV2JZcGJsd258RHh3SXN0cmRXYllwYmx3bnwxMTk="
        },
        {
            "key": "云端",
            "name": "云端｜APP",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 2,
            "ext": "jaHR0cHM6Ly95ZHlzZHluYW1pY2RvbWFpbm5hbWUuNjguZ3k6MTA2NzgvYzltMmpzMjk4eDgyaDYvbDltOGJ4MjNqMm8ycDlxL2R5bmFtaWNkb21haW5uYW1lLnR4dHxrOW8zcDJjOGI3bTN6MG84fGs5bzNwMmM4YjdtM3owbzh8MTAw"
        },
        {
            "key": "蝴蝶",
            "name": "蝴蝶｜APP",
            "type": 3,
            "api": "csp_Hudie",
            "playerType": 2,
            "ext": "eaHR0cHM6Ly9kLmRjbW92aWUudG9w"
        },
        {
            "key": "快看",
            "name": "快看｜APP",
            "type": 3,
            "api": "csp_AppYsV2",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "ext": "http://kkwk123.top/api.php/app/"
        },
        {
            "key": "移动",
            "name": "移动｜APP",
            "type": 3,
            "api": "csp_YD",
            "searchable": 1,
            "quickSearch": 1
        },
        {
            "key": "厂长影视",
            "name": "厂长｜影视",
            "type": 3,
            "playerType": "2",
            "api": "csp_Czsapp",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "ext": "http://www.czzyvideo.com"
        },
        {
            "key": "糯米影视",
            "name": "糯米┃影视",
            "type": 3,
            "api": "csp_Wwys",
            "ext": "https://www.wwgz.cn"
        },
        {
            "key": "私人影视",
            "name": "私人｜影视",
            "type": 3,
            "api": "csp_Siren"
        },
        {
            "key": "云播影视",
            "name": "云播｜影视",
            "type": 3,
            "api": "csp_Tvyb"
        },
        {
            "key": "奇优影视",
            "name": "奇优｜影视",
            "type": 3,
            "api": "csp_Qiyou"
        },
        {
            "key": "苹果影视",
            "name": "苹果｜影视",
            "type": 3,
            "api": "csp_LiteApple",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "全网影视",
            "name": "全看｜影视",
            "type": 3,
            "api": "csp_Quanwk",
            "ext": "https://www.91qkw.com"
        },
        {
            "key": "饺子影视",
            "name": "饺子｜影视",
            "type": 3,
            "api": "csp_Jiaozi",
            "playerType": 2
        },
        {
            "key": "火火影视",
            "name": "火火｜影视",
            "type": 3,
            "api": "csp_SaoHuo",
            "playerType": 2,
            "ext": "https://shdy5.us"
        },
        {
            "key": "菲儿影视",
            "name": "菲菲｜影视",
            "type": 3,
            "api": "csp_AppFerr",
            "ext": "sHR2rlsfjI4L3t4RXQMkn/M3t4AXAKTrZj3tfhm1t/gMT3dOrHqIzUNqLUEOIDMvllTbX6e1hMhB2mfpOaCmHNOL1yBB3SmxNyqXlai90EIpdnwOOgCR9Z+YwCTj6ySjzJ2VBiH3eXeOGcavcNeVRA=="
        },
        {
            "key": "金牌影视",
            "name": "金牌｜影视",
            "type": 3,
            "api": "csp_Jpys"
        },
        {
            "key": "尘落影视",
            "name": "尘落｜影视",
            "type": 3,
            "api": "csp_Wetv",
            "searchable": 1,
            "quickSearch": 1
        },
        {
            "key": "低端影视",
            "name": "低端｜影视",
            "type": 3,
            "api": "csp_Ddys",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "快看影视",
            "name": "快看｜影视",
            "type": 3,
            "api": "csp_Kuaikan",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "饭团影视",
            "name": "饭团｜影视",
            "type": 3,
            "api": "csp_Fantuan",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "来看影视",
            "name": "来看｜影视",
            "type": 3,
            "api": "csp_Lkdy",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "瓜子影视",
            "name": "瓜子｜影视",
            "type": 3,
            "api": "csp_Gz360",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "西瓜视频",
            "name": "西瓜｜视频",
            "type": 3,
            "api": "csp_AmuXiguaV2",
            "searchable": 1,
            "quickSearch": 0,
            "filterable": 0,
            "changeable": 0,
            "style": {
                "type": "rect",
                "ratio": 1.597
            }
        },
        {
            "key": "采集之王",
            "name": "采集｜合集",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/采集之王.js?type=url&params=../json/采集静态.json$1$1"
        },
        {
            "key": "爱看机器人",
            "name": "爱看｜影视",
            "type": 3,
            "api": "csp_IkanBot",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "农民影视",
            "name": "农民｜影视",
            "type": 3,
            "api": "csp_XBPQ",
            "ext": "./XBPQ/农民影视.json"
        },
        {
            "key": "秀儿影视",
            "name": "秀儿｜影视",
            "type": 3,
            "api": "csp_XBPQ",
            "ext": "./XBPQ/秀儿影视.json"
        },
        {
            "key": "小枫影视",
            "name": "小枫｜影视",
            "type": 3,
            "api": "csp_XBPQ",
            "ext": "./XBPQ/小枫影视.json"
        },
        {
            "key": "奇迹影视",
            "name": "奇迹｜影视",
            "type": 3,
            "api": "csp_XBPQ",
            "ext": "./XBPQ/奇迹影视.json"
        },
        {
            "key": "可可影视",
            "name": "可可｜影视",
            "type": 3,
            "api": "csp_XBPQ",
            "ext": "./XBPQ/可可影视.json"
        },
        {
            "key": "海纳影视",
            "name": "海纳｜影视",
            "type": 3,
            "api": "csp_XBPQ",
            "ext": "./XBPQ/海纳影视.json"
        },
        {
            "key": "面包影视",
            "name": "面包｜影视",
            "type": 3,
            "api": "csp_XBPQ",
            "ext": "./XBPQ/面包影视.json"
        },
        {
            "key": "永乐影视",
            "name": "永乐｜影视",
            "type": 3,
            "api": "csp_XBPQ",
            "ext": "./XBPQ/永乐影视.json"
        },
        {
            "key": "雪糕影视",
            "name": "雪糕｜影视",
            "type": 3,
            "api": "csp_XBPQ",
            "ext": "./XBPQ/雪糕影视.json"
        },
        {
            "key": "流光影视",
            "name": "流光｜影视",
            "type": 3,
            "api": "csp_XBPQ",
            "ext": "./XBPQ/流光影视.json"
        },
        {
            "key": "一起影视",
            "name": "一起｜影视",
            "type": 3,
            "api": "csp_AppFree4K",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 0,
            "ext": "w7TCmsONw6LDrsKYwoXCosKcwqDCrcKawqDDosKnwqTCoMKjwrPCosKpw5rDqsKjwpPCncKjwqfDmcOsw57Dn8KbwpRewqbDosOjwqHCpcKaWnvClcKpwqDCrcKawqDDnMKYZWNkwrHDl8Ogw5vCqsKWY8KTYsKxwqbCocKlwppaecKmV8KzwpPCocKuw6BoZGRpw53Dl8Krwq3CrWRjYmHCsMKawqbCmcKhdcKRwp7Cm8OHw5TDsMKgwrRTV+ecpOaTncKgwp/CmsKgw4rClMKiwqPClcOOw6XDpsKgwrRTV8KYwqTDrcOjw63Cs8KpYsKRwqDCoMOvwqTCqMOfw6zCmMKVwpjClMKnw6nDo8OpwqnCncKjwp/CnsKnw6PDosOpwrnCqMKiwpxtwqDCn8KawqDCvsKUwp59wqXDjsOlw6bCoMK0U1fCmMKkw63Do8OtwrPCqWLClMKdXsOvw5zDnsOzwqjClMKjwpnCkcKow5fDp8Okw69ib8KRwpPCtsOXw6fCn8OuwqLCm8KVwp7CtsOEw4PDhcK8dnh6dsOMwr/DkcOPw4B4e8KCVsOuw6XDpsK2wqFfUFfClMOew5bDrMOyw6rCp3vClcKpwqDCrcKawqDDscKowqnCmWbCr8KpwqHDtg=="
        },
        {
            "key": "耐看影视",
            "name": "耐看｜影视",
            "type": 3,
            "api": "csp_WebNK",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "ext": "w7TClcONw6LDrsKYwoXCosKcwpvCrcKcw6HDrsKnwqDCo2rCqMKiw7HDsMOxYcKewpvClMOvw5fCqMOmw59VXFLCpMOiw6PCnMKzwpzCjuWGtemEmOaPleWRnMKf5Yem5L6Q5ZGxbeW+oeintui1tOa8ieetjMOXwpvDtw=="
        },
        {
            "key": "真心影视",
            "name": "真心｜影视",
            "type": 3,
            "api": "csp_WebGZ",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "思古影视",
            "name": "思古｜影视",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/思古影视.js"
        },
        {
            "key": "追剧影视",
            "name": "追剧｜影视",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/追剧视频.js"
        },
        {
            "key": "魔力高清",
            "name": "魔力｜影视",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/魔力高清.js"
        },
        {
            "key": "碟调影视",
            "name": "碟调｜影视",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/碟调影视.js"
        },
   
   
        {
            "key": "剧圈圈",
            "name": "剧圈圈｜影视",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/剧圈圈.js"
        },
        {
            "key": "看了么",
            "name": "看了么｜影视",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/看了么.js"
        },
        {
            "key": "茶杯狐",
            "name": "茶杯狐｜影视",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/茶杯狐.js"
        },
        {
            "key": "1905",
            "name": "1905｜影视",
            "type": 3,
            "api": "csp_Web1905",
            "searchable": 1,
            "quickSearch": 0,
            "filterable": 0
        },
        {
            "key": "红牛资源",
            "name": "红牛｜采集",
            "type": 1,
            "api": "https://www.hongniuzy2.com/api.php/provide/vod/",
            "searchable": 1,
            "changeable": 1,
            "categories": [
                "动作片",
                "喜剧片",
                "爱情片",
                "科幻片",
                "恐怖片",
                "剧情片",
                "战争片",
                "国产剧",
                "港澳剧",
                "日剧",
                "欧美剧",
                "台湾剧",
                "泰剧",
                "韩剧",
                "纪录片",
                "动漫电影"
            ]
        },
        {
            "key": "光速资源",
            "name": "光速｜采集",
            "type": 1,
            "api": "http://api.guangsuapi.com/api.php/provide/vod/",
            "searchable": 1,
            "changeable": 1,
            "categories": [
                "动作片",
                "喜剧片",
                "爱情片",
                "科幻片",
                "剧情片",
                "恐怖片",
                "战争片",
                "动漫电影",
                "大陆剧",
                "欧美剧",
                "港澳剧",
                "韩剧",
                "日剧",
                "台湾剧",
                "泰剧",
                "综艺",
                "动漫",
                "记录片"
            ]
        },
        {
            "key": "极速资源",
            "name": "极速｜采集",
            "type": 1,
            "api": "https://jszyapi.com/api.php/provide/vod/",
            "searchable": 1,
            "changeable": 1,
            "categories": [
                "日剧",
                "马泰剧",
                "内地剧",
                "欧美剧",
                "香港剧",
                "韩剧",
                "台湾剧",
                "恐怖片",
                "动画片",
                "剧情片",
                "战争片",
                "动作片",
                "记录片",
                "爱情片",
                "喜剧片",
                "科幻片",
                "灾难片",
                "悬疑片",
                "犯罪片",
                "中国动漫",
                "日本动漫",
                "欧美动漫"
            ]
        },
        {
            "key": "快车资源",
            "name": "快车｜采集",
            "type": 1,
            "api": "https://caiji.kczyapi.com/api.php/provide/vod/",
            "searchable": 1,
            "changeable": 1,
            "categories": [
                "动作片",
                "喜剧片",
                "爱情片",
                "科幻片",
                "恐怖片",
                "战争片",
                "剧情片",
                "动画片",
                "纪录片",
                "国产剧",
                "香港剧",
                "台湾剧",
                "欧美剧",
                "韩国剧",
                "日本剧",
                "泰国剧",
                "海外剧",
                "国产动漫",
                "日本动漫",
                "欧美动漫",
                "大陆综艺",
                "日韩综艺",
                "港台综艺",
                "欧美综艺"
            ]
        },
        {
            "key": "索尼资源",
            "name": "索尼｜采集",
            "type": 1,
            "api": "https://suoniapi.com/api.php/provide/vod/",
            "searchable": 1,
            "changeable": 1,
            "categories": [
                "动作片",
                "喜剧片",
                "爱情片",
                "科幻片",
                "恐怖片",
                "剧情片",
                "战争片",
                "纪录片",
                "动画片",
                "国产剧",
                "欧美剧",
                "韩剧",
                "日剧",
                "港剧",
                "台剧",
                "泰剧",
                "海外剧",
                "大陆综艺",
                "日韩综艺",
                "港台综艺",
                "欧美综艺",
                "国产动漫",
                "日韩动漫",
                "欧美动漫",
                "港台动漫",
                "海外动漫"
            ]
        },
        {
            "key": "量子资源",
            "name": "量子｜采集",
            "type": 1,
            "api": "https://cj.lziapi.com/api.php/provide/vod/",
            "searchable": 1,
            "changeable": 1,
            "categories": [
                "动作片",
                "喜剧片",
                "科幻片",
                "恐怖片",
                "爱情片",
                "剧情片",
                "战争片",
                "记录片",
                "国产剧",
                "欧美剧",
                "香港剧",
                "韩国剧",
                "台湾剧",
                "日本剧",
                "海外剧",
                "泰国剧",
                "国产动漫",
                "日韩动漫",
                "欧美动漫",
                "港台动漫",
                "海外动漫",
                "大陆综艺",
                "港台综艺",
                "日韩综艺",
                "欧美综艺"
            ]
        },
        {
            "key": "非凡资源",
            "name": "非凡｜采集",
            "type": 1,
            "api": "http://cj.ffzyapi.com/api.php/provide/vod/",
            "searchable": 1,
            "changeable": 1,
            "categories": [
                "动作片",
                "喜剧片",
                "科幻片",
                "恐怖片",
                "爱情片",
                "剧情片",
                "战争片",
                "记录片",
                "国产剧",
                "欧美剧",
                "香港剧",
                "韩国剧",
                "台湾剧",
                "日本剧",
                "海外剧",
                "泰国剧",
                "国产动漫",
                "日韩动漫",
                "欧美动漫",
                "港台动漫",
                "海外动漫",
                "大陆综艺",
                "港台综艺",
                "日韩综艺",
                "欧美综艺"
            ]
        },
        {
            "key": "哆啦新番社",
            "name": "哆啦｜新番社",
            "type": 3,
            "api": "csp_XBPQ",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "style": {
                "type": "list"
            },
            "ext": "./XBPQ/哆啦新番社.json"
        },
        {
            "key": "56动漫",
            "name": "56｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/56动漫.js"
        },
        {
            "key": "NT动漫",
            "name": "NT｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/NT动漫.js"
        },
        {
            "key": "Anime1",
            "name": "Anime1｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/Anime1.js"
        },
        {
            "key": "曼波动漫",
            "name": "曼波｜动漫",
            "type": 3,
            "api": "csp_Xdai",
            "searchable": 1,
            "quickSearch": 0,
            "filterable": 0,
            "ext": "jaHR0cHM6Ly9hcHAub21vZnVuMS50b3AvYXBpLnBocHw2NmRjMzA5Y2JlZWNhNDU0fDY2ZGMzMDljYmVlY2E0NTR8MTAw"
        },
        {
            "key": "稀饭动漫",
            "name": "稀饭｜动漫",
            "type": 3,
            "api": "csp_Xdai",
            "searchable": 1,
            "quickSearch": 0,
            "filterable": 0,
            "ext": "jaHR0cHM6Ly94ZmFwcC0xMzA1MzkwMDY1LmNvcy5hcC1ndWFuZ3pob3UubXlxY2xvdWQuY29tL2dldGFwcC50eHR8MXlaMlNwbjlrcm56VktvQ3wxeVoyU3BuOWtybnpWS29DfDEwMA=="
        },
        {
            "key": "咕咕动漫",
            "name": "咕咕｜动漫",
            "type": 3,
            "api": "csp_Xdai",
            "playerType": 1,
            "ext": "jaHR0cHM6Ly93d3cuZ3VndTMuY29tfG5LZlo4S1g2SlROV1J6VER8bktmWjhLWDZKVE5XUnpURHw0MDE="
        },
        {
            "key": "动画片",
            "name": "动画片｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/动画片大全.js"
        },
        {
            "key": "路漫漫",
            "name": "路漫漫｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/路漫漫.js"
        },
        {
            "key": "动漫岛",
            "name": "动漫岛｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/动漫岛.js"
        },
        {
            "key": "去看吧",
            "name": "去看吧｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/去看吧.js"
        },
        {
            "key": "爱弹幕",
            "name": "爱弹幕｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/爱弹幕.js"
        },
        {
            "key": "异世界",
            "name": "异世界｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/异世界.js"
        },
        {
            "key": "好看动漫",
            "name": "好看｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/好看动漫.js"
        },
        {
            "key": "奇米动漫",
            "name": "奇米｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/奇米动漫.js"
        },
        {
            "key": "怡萱动漫",
            "name": "怡萱｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/怡萱动漫.js"
        },
        {
            "key": "花子动漫",
            "name": "花子｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/花子动漫.js"
        },
        {
            "key": "动漫巴士",
            "name": "巴士｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/动漫巴士.js"
        },
        {
            "key": "樱花动漫",
            "name": "樱花｜动漫",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "ext": "./js/樱花动漫.js"
        },
        {
            "key": "搜索弹幕",
            "name": "搜索｜弹幕",
            "type": 3,
            "api": "csp_PanSearch",
            "searchable": 1,
            "filterable": 0,
            "changeable": 1,
            "ext": {
                "token": "http://127.0.0.1:9978/file/TVBox/token.txt",
                "danmu": true
            }
        },
        {
            "key": "易搜弹幕",
            "name": "易搜｜弹幕",
            "type": 3,
            "api": "csp_YiSo",
            "searchable": 1,
            "filterable": 0,
            "changeable": 1,
            "ext": {
                "token": "http://127.0.0.1:9978/file/TVBox/token.txt",
                "danmu": true,
                "cookie": "satoken=0eedba28-be8a-4f01-81af-2d8d44808ecf"
            }
        },
        {
            "key": "云盘弹幕",
            "name": "云盘｜弹幕",
            "type": 3,
            "api": "csp_Yunpan4k",
            "searchable": 1,
            "filterable": 0,
            "changeable": 1,
            "ext": {
                "token": "http://127.0.0.1:9978/file/TVBox/token.txt",
                "cookie": "http://127.0.0.1:9978/file/TVBox/quark.txt",
                "danmu": true
            }
        },
        {
            "key": "夸搜弹幕",
            "name": "夸搜｜弹幕",
            "type": 3,
            "api": "csp_Qkso",
            "searchable": 1,
            "filterable": 1,
            "changeable": 0,
            "ext": {
                "cookie": "http://127.0.0.1:9978/file/TVBox/quark.txt",
                "danmu": true
            }
        },
        {
            "key": "小纸条弹幕",
            "name": "小纸条｜弹幕",
            "type": 3,
            "api": "csp_XiaoZhiTiao",
            "searchable": 1,
            "filterable": 1,
            "changeable": 0,
            "ext": {
                "token": "http://127.0.0.1:9978/file/TVBox/token.txt",
                "danmu": true
            }
        },
        {
            "key": "夸克趣盘搜弹幕",
            "name": "趣盘搜｜弹幕",
            "type": 3,
            "api": "csp_QuPanSou",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "changeable": 1,
            "ext": {
                "cookie": "http://127.0.0.1:9978/file/TVBox/quark.txt",
                "danmu": true
            }
        },
        {
            "key": "夸克短剧弹幕",
            "name": "夸克短剧｜弹幕",
            "type": 3,
            "api": "csp_Qkdj",
            "searchable": 1,
            "filterable": 1,
            "changeable": 0,
            "ext": {
                "cookie": "http://127.0.0.1:9978/file/TVBox/quark.txt",
                "danmu": true
            }
        },
        {
            "key": "荐片",
            "name": "荐片｜磁力",
            "api": "csp_Jianpian",
            "type": 3,
            "playerType": 1,
            "ext": "http://api2.rinhome.com"
        },
        {
            "key": "修罗影视",
            "name": "修罗｜磁力",
            "type": 3,
            "api": "csp_XBPQ",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "ext": "./XBPQ/修罗影视.json"
        },
        {
            "key": "七味",
            "name": "七味｜磁力",
            "type": 3,
            "api": "csp_QnMp4",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "80S",
            "name": "80S｜磁力",
            "type": 3,
            "api": "csp_BLSGod",
            "playerType": 1,
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "New6v",
            "name": "New6V｜磁力",
            "type": 3,
            "api": "csp_New6v",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "ext": "https://www.xb6v.com"
        },
        {
            "key": "SeedHub",
            "name": "SeedHub｜磁力",
            "type": 3,
            "api": "csp_SeedHub",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "美剧迷",
            "name": "美剧迷｜磁力",
            "type": 3,
            "api": "csp_MeijuMi",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "迅雷吧",
            "name": "迅雷吧｜磁力",
            "type": 3,
            "api": "csp_Xunlei8",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
    
        {
            "key": "狐狸君",
            "name": "狐狸君｜磁力",
            "type": 3,
            "api": "csp_XBPQ",
            "changeable": 1,
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "ext": "./XBPQ/狐狸君.json"
        },
        {
            "key": "布谷TV",
            "name": "布谷TV｜磁力",
            "type": 3,
            "api": "csp_XBPQ",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1,
            "ext": "./XBPQ/布谷TV.json"
        },
    
        {
            "key": "Mp4电影",
            "name": "Mp4电影｜磁力",
            "type": 3,
            "api": "csp_Mp4Mov",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "酷吧电影",
            "name": "酷吧电影｜磁力",
            "type": 3,
            "api": "csp_KubaCL",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "美剧天堂",
            "name": "美剧天堂｜磁力",
            "type": 3,
            "api": "csp_MeijuTT",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "电影天堂",
            "name": "电影天堂｜磁力",
            "type": 3,
            "api": "csp_DyGod",
            "searchable": 1,
            "quickSearch": 1,
            "filterable": 1
        },
        {
            "key": "我的阿里",
            "name": "我的｜阿里",
            "type": 3,
            "api": "csp_MyAli",
            "searchable": 0,
            "quickSearch": 0,
            "filterable": 0,
            "indexs": 0,
            "ext": {
                "token": "http://127.0.0.1:9978/file/TVBox/token.txt"
            },
            "style": {
                "type": "list"
            }
        },
        {
            "key": "我的夸克",
            "name": "我的｜夸克",
            "type": 3,
            "api": "csp_MyQuark",
            "searchable": 0,
            "quickSearch": 0,
            "filterable": 0,
            "indexs": 0,
            "ext": {
                "cookie": "http://127.0.0.1:9978/file/TVBox/quark.txt"
            },
            "style": {
                "type": "list"
            }
        },
        {
            "key": "我的UC",
            "name": "我的｜UC",
            "type": 3,
            "api": "csp_MyUc",
            "searchable": 0,
            "quickSearch": 0,
            "filterable": 0,
            "indexs": 0,
            "ext": {
                "uc_cookie": "http://127.0.0.1:9978/file/TVBox/uc.txt"
            },
            "style": {
                "type": "list"
            }
        },
        {
            "key": "阿里合集",
            "name": "阿里｜合集",
            "type": 3,
            "api": "csp_AliShare",
            "searchable": 1,
            "changeable": 0,
            "filterable": 0,
            "indexs": 0,
            "ext": {
                "token": "http://127.0.0.1:9978/file/TVBox/token.txt",
                "share": "./js/alishare.txt"
            },
            "style": {
                "type": "list"
            }
        },
        {
            "key": "短剧合集",
            "name": "短剧｜合集",
            "type": 3,
            "api": "./js/quark.min.js",
            "ext": "./js/短剧合集.js",
            "style": {
                "type": "list"
            }
        },
        {
            "key": "AList",
            "name": "AList｜合集",
            "type": 3,
            "api": "csp_Alist",
            "searchable": 1,
            "filterable": 1,
            "changeable": 0,
            "style": {
                "type": "list"
            },
            "ext": "./json/alist.json"
        },
        {
            "key": "网络直播",
            "name": "网络｜直播",
            "type": 3,
            "api": "csp_Living",
            "searchable": 1
        },
        {
            "key": "88看球",
            "name": "88｜看球",
            "type": 3,
            "api": "./js/drpy2.min.js",
            "style": {
                "type": "list"
            },
            "ext": "./js/88看球.js"
        },
        {
            "key": "急救教学",
            "name": "急救｜教学",
            "type": 3,
            "api": "csp_FirstAid",
            "searchable": 0,
            "quickSearch": 0,
            "changeable": 0,
            "style": {
                "type": "rect",
                "ratio": 3.8
            },
            "gridview": "0-0-4.1"
        },
        {
            "key": "版本信息",
            "name": "版本｜信息",
            "type": 3,
            "api": "csp_Market",
            "searchable": 0,
            "changeable": 0,
            "indexs": 0,
            "ext": "https://9877.kstore.space/Market/market.json"
        },
        {
            "key": "push_agent",
            "name": "手机｜推送",
            "type": 3,
            "api": "csp_Push",
            "searchable": 0,
            "filterable": 0,
            "changeable": 0
        }
    ],
    "parses": [
        {
            "name": "夏夜",
            "type": "1",
            "url": "http://8.155.50.80/xiaye.php?url=",
            "ext": {
                "flag": [
                    "qq",
                    "腾讯",
                    "qiyi",
                    "爱奇艺",
                    "奇艺",
                    "youku",
                    "优酷",
                    "sohu",
                    "搜狐",
                    "letv",
                    "乐视",
                    "mgtv",
                    "芒果",
                    "tnmb",
                    "seven",
                    "bilibili",
                    "1905"
                ],
                "header": {
                    "User-Agent": "okhttp/4.9.1"
                }
            }
        },
        {
            "name": "羊羊",
            "type": 1,
            "url": "http://117.50.184.199:94/api.php/?key=1&url=",
            "ext": {
                "flag": [
                    "qq",
                    "腾讯",
                    "qiyi",
                    "爱奇艺",
                    "奇艺",
                    "youku",
                    "优酷",
                    "sohu",
                    "搜狐",
                    "letv",
                    "乐视",
                    "mgtv",
                    "芒果",
                    "tnmb",
                    "seven",
                    "bilibili",
                    "1905"
                ],
                "header": {
                    "User-Agent": "okhttp/4.9.1"
                }
            }
        },
        {
            "name": "臻享",
            "type": "1",
            "url": "https://zy.qiaoji8.com/gouzi.php?url=",
            "ext": {
                "flag": [
                    "qq",
                    "腾讯",
                    "qiyi",
                    "爱奇艺",
                    "奇艺",
                    "youku",
                    "优酷",
                    "sohu",
                    "搜狐",
                    "letv",
                    "乐视",
                    "mgtv",
                    "芒果",
                    "tnmb",
                    "seven",
                    "bilibili",
                    "1905"
                ],
                "header": {
                    "User-Agent": "okhttp/4.9.1"
                }
            }
        },
        {
            "name": "优选",
            "type": 1,
            "url": "http://1.94.221.189:88/algorithm.php?url=",
            "ext": {
                "flag": [
                    "qq",
                    "腾讯",
                    "qiyi",
                    "爱奇艺",
                    "奇艺",
                    "youku",
                    "优酷",
                    "sohu",
                    "搜狐",
                    "letv",
                    "乐视",
                    "mgtv",
                    "芒果",
                    "tnmb",
                    "seven",
                    "bilibili",
                    "1905"
                ],
                "header": {
                    "User-Agent": "okhttp/4.9.1"
                }
            }
        },
        {
            "name": "至臻",
            "type": 1,
            "url": "http://yunhai.qijiyun.vip/home/api?type=ys&uid=177259&key=dijnouxKNOQSTUWXY5&url=",
            "ext": {
                "flag": [
                    "qq",
                    "腾讯",
                    "qiyi",
                    "爱奇艺",
                    "奇艺",
                    "youku",
                    "优酷",
                    "sohu",
                    "搜狐",
                    "letv",
                    "乐视",
                    "mgtv",
                    "芒果",
                    "tnmb",
                    "seven",
                    "bilibili",
                    "1905"
                ],
                "header": {
                    "User-Agent": "okhttp/4.9.1"
                }
            }
        },
        {
            "name": "无双",
            "type": 1,
            "url": "http://1.94.221.189:88/algorithm.php?url=",
            "ext": {
                "flag": [
                    "hgvip"
                ],
                "header": {
                    "User-Agent": "okhttp/4.9.1"
                }
            }
        },
        {
            "name": "咸鱼",
            "type": 0,
            "url": "https://jx.xymp4.cc/?url=",
            "ext": {
                "header": {
                    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.3124.68"
                }
            }
        },
        {
            "name": "虾米",
            "type": 0,
            "url": "https://jx.xmflv.com/?url=",
            "ext": {
                "header": {
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.57"
                }
            }
        },
        {
            "name": "淘片",
            "type": 0,
            "url": "https://jx.yparse.com/index.php?url=",
            "ext": {
                "header": {
                    "user-agent": "Mozilla/5.0 (Linux; Android 13; V2049A Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36"
                }
            }
        },
        {
            "name": "冰豆",
            "type": 0,
            "url": "https://bd.jx.cn/?url=",
            "ext": {
                "header": {
                    "user-agent": "Mozilla/5.0 (Linux; Android 13; V2049A Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36"
                }
            }
        },
        {
            "name": "七七",
            "type": 0,
            "url": "https://jx.77flv.cc/?url=",
            "ext": {
                "header": {
                    "user-agent": "Mozilla/5.0 (Linux; Android 13; V2049A Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36"
                }
            }
        },
        {
            "name": "盘古",
            "type": 0,
            "url": "https://www.playm3u8.cn/jiexi.php?url=",
            "ext": {
                "header": {
                    "user-agent": "Mozilla/5.0 (Linux; Android 13; V2049A Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36"
                }
            }
        },
        {
            "name": "夜幕",
            "type": 0,
            "url": "https://yemu.xyz/?url=",
            "ext": {
                "header": {
                    "user-agent": "Mozilla/5.0 (Linux; Android 13; V2049A Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/116.0.0.0 Mobile Safari/537.36"
                }
            }
        }
    ],
    "rules": [
        {
            "name": "农民",
            "hosts": [
                "toutiaovod.com"
            ],
            "regex": [
                "video/tos/cn"
            ]
        },
        {
            "name": "火山",
            "hosts": [
                "huoshan.com"
            ],
            "regex": [
                "item_id="
            ]
        },
        {
            "name": "抖音",
            "hosts": [
                "douyin.com"
            ],
            "regex": [
                "is_play_url="
            ]
        },
        {
            "name": "饭团点击",
            "hosts": [
                "dadagui",
                "freeok",
                "dadagui"
            ],
            "script": [
                "document.querySelector(\"#playleft iframe\").contentWindow.document.querySelector(\"#start\").click();"
            ]
        },
        {
            "name": "毛驴点击",
            "hosts": [
                "www.maolvys.com"
            ],
            "script": [
                "document.getElementsByClassName('swal-button swal-button--confirm')[0].click()"
            ]
        },
        {
            "name": "ofiii",
            "hosts": [
                "www.ofiii.com"
            ],
            "script": [
                "const play=document.getElementsByClassName('play_icon')[0],event=new MouseEvent('click',{bubbles:!0,cancelable:!0,view:window,screenX:100,screenY:100,clientX:50,clientY:50,button:0,shiftKey:!1,ctrlKey:!1,altKey:!1,metaKey:!1,modifierState:0});play.dispatchEvent(event);"
            ]
        }
    ],
    "doh": [
        {
            "name": "Google",
            "url": "https://dns.google/dns-query",
            "ips": [
                "8.8.4.4",
                "8.8.8.8"
            ]
        },
        {
            "name": "Cloudflare",
            "url": "https://cloudflare-dns.com/dns-query",
            "ips": [
                "1.1.1.1",
                "1.0.0.1",
                "2606:4700:4700::1111",
                "2606:4700:4700::1001"
            ]
        },
        {
            "name": "AdGuard",
            "url": "https://dns.adguard.com/dns-query",
            "ips": [
                "94.140.14.140",
                "94.140.14.141"
            ]
        },
        {
            "name": "DNSWatch",
            "url": "https://resolver2.dns.watch/dns-query",
            "ips": [
                "84.200.69.80",
                "84.200.70.40"
            ]
        },
        {
            "name": "Quad9",
            "url": "https://dns.quad9.net/dns-quer",
            "ips": [
                "9.9.9.9",
                "149.112.112.112"
            ]
        }
    ],
    "lives": [
        {
            "name": "AI直播",
            "type": 0,
            "url": "https://gh-proxy.com/https://raw.githubusercontent.com/PizazzGY/TV/master/output/user_result.txt",
            "epg": "http://cdn.1678520.xyz/epg/?ch={name}&date={date}",
            "playerType": 2,
            "timeout": 10
        },
        {
            "name": "电视Live",
            "type": 0,
            "url": "http://127.0.0.1:9978/proxy?do=live&u=Gather",
            "playerType": 2,
            "timeout": 10
        },
        {
            "name": "网络Live",
            "type": 0,
            "url": "http://127.0.0.1:9978/proxy?do=live&url=https://tv.iill.top/m3u/Live",
            "playerType": 2,
            "timeout": 10
        },
        {
            "name": "范明明",
            "type": 0,
            "url": "https://live.fanmingming.cn/tv/m3u/ipv6.m3u",
            "playerType": 2,
            "timeout": 10
        },
        {
            "name": "APTV",
            "type": 0,
            "url": "https://gh-proxy.com/https://github.com/Kimentanm/aptv/raw/master/m3u/iptv.m3u",
            "epg": "http://epg.51zmt.top:8000/api/diyp/?ch={name}&date={date}",
            "logo": "https://epg.iill.top/logo/{name}.png",
            "ua": "okhttp/3.15,AptvPlayer/1.4.0",
            "timeout": 10,
            "playerType": 2
        }
    ],
    "hosts": [
        "cache.ott.*.itv.cmvideo.cn=base-v4-free-mghy.e.cdn.chinamobile.com",
        "cache.ott.ystenlive.itv.cmvideo.cn=base-v4-free-mghy.e.cdn.chinamobile.com",
        "cache.ott.bestlive.itv.cmvideo.cn=base-v4-free-mghy.e.cdn.chinamobile.com",
        "cache.ott.wasulive.itv.cmvideo.cn=base-v4-free-mghy.e.cdn.chinamobile.com",
        "cache.ott.fifalive.itv.cmvideo.cn=base-v4-free-mghy.e.cdn.chinamobile.com",
        "cache.ott.hnbblive.itv.cmvideo.cn=base-v4-free-mghy.e.cdn.chinamobile.com"
    ],
    "flags": [
        "youku",
        "优酷",
        "优 酷",
        "优酷视频",
        "qq",
        "腾讯",
        "腾 讯",
        "腾讯视频",
        "iqiyi",
        "qiyi",
        "奇艺",
        "爱奇艺",
        "爱 奇 艺",
        "m1905",
        "xigua",
        "letv",
        "leshi",
        "乐视",
        "乐 视",
        "sohu",
        "搜狐",
        "搜 狐",
        "搜狐视频",
        "tudou",
        "pptv",
        "mgtv",
        "芒果",
        "imgo",
        "芒果TV",
        "芒 果 T V",
        "bilibili",
        "哔 哩",
        "哔 哩 哔 哩"
    ],
    "ijk": [
        {
            "group": "软解码",
            "options": [
                {
                    "category": 4,
                    "name": "opensles",
                    "value": "0"
                },
                {
                    "category": 4,
                    "name": "overlay-format",
                    "value": "842225234"
                },
                {
                    "category": 4,
                    "name": "framedrop",
                    "value": "1"
                },
                {
                    "category": 4,
                    "name": "soundtouch",
                    "value": "1"
                },
                {
                    "category": 4,
                    "name": "start-on-prepared",
                    "value": "1"
                },
                {
                    "category": 1,
                    "name": "http-detect-range-support",
                    "value": "0"
                },
                {
                    "category": 1,
                    "name": "fflags",
                    "value": "fastseek"
                },
                {
                    "category": 2,
                    "name": "skip_loop_filter",
                    "value": "48"
                },
                {
                    "category": 4,
                    "name": "reconnect",
                    "value": "1"
                },
                {
                    "category": 4,
                    "name": "enable-accurate-seek",
                    "value": "0"
                },
                {
                    "category": 4,
                    "name": "mediacodec",
                    "value": "0"
                },
                {
                    "category": 4,
                    "name": "mediacodec-auto-rotate",
                    "value": "0"
                },
                {
                    "category": 4,
                    "name": "mediacodec-handle-resolution-change",
                    "value": "0"
                },
                {
                    "category": 4,
                    "name": "mediacodec-hevc",
                    "value": "0"
                },
                {
                    "category": 1,
                    "name": "dns_cache_timeout",
                    "value": "600000000"
                }
            ]
        },
        {
            "group": "硬解码",
            "options": [
                {
                    "category": 4,
                    "name": "opensles",
                    "value": "0"
                },
                {
                    "category": 4,
                    "name": "overlay-format",
                    "value": "842225234"
                },
                {
                    "category": 4,
                    "name": "framedrop",
                    "value": "1"
                },
                {
                    "category": 4,
                    "name": "soundtouch",
                    "value": "1"
                },
                {
                    "category": 4,
                    "name": "start-on-prepared",
                    "value": "1"
                },
                {
                    "category": 1,
                    "name": "http-detect-range-support",
                    "value": "0"
                },
                {
                    "category": 1,
                    "name": "fflags",
                    "value": "fastseek"
                },
                {
                    "category": 2,
                    "name": "skip_loop_filter",
                    "value": "48"
                },
                {
                    "category": 4,
                    "name": "reconnect",
                    "value": "1"
                },
                {
                    "category": 4,
                    "name": "enable-accurate-seek",
                    "value": "0"
                },
                {
                    "category": 4,
                    "name": "mediacodec",
                    "value": "1"
                },
                {
                    "category": 4,
                    "name": "mediacodec-auto-rotate",
                    "value": "1"
                },
                {
                    "category": 4,
                    "name": "mediacodec-handle-resolution-change",
                    "value": "1"
                },
                {
                    "category": 4,
                    "name": "mediacodec-hevc",
                    "value": "1"
                },
                {
                    "category": 1,
                    "name": "dns_cache_timeout",
                    "value": "600000000"
                }
            ]
        }
    ],
    "ads": [
        "static-mozai.4gtv.tv"
    ]
}